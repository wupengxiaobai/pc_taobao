# nodeBaseServer

node 基础服务

## controller 控制器

## modeles 数据模型

## routes 路由

## utils 工具

## 编写日志

- 2019/8/5
  - 基础的 mvc 模式测试 test 接口
- 2019/8/7 
  - mysql 的引入
