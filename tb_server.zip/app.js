const express = require('express')
const bodyParser = require('body-parser')
const path = require('path')
const cors = require('cors')
const app = express()
const {
  baseConfig,
  config
} = require('./config')

const API_LINK = '/api_test/';
const PREV_LINK = '/pc_taobao/';

const testRoute = require('./routes/test')
const port = baseConfig.port ? baseConfig.port : 9001

//  配置body-parser中间件
app.use(bodyParser.urlencoded({
  extended: false
}))
app.use(bodyParser.json())

//  配置跨域
app.use(cors())

app.use(API_LINK + 'test', testRoute)

// 开放静态资源 /pc_taobao
app.use(PREV_LINK + 'client/', express.static(path.join(__dirname, 'client')))

// art 模板引擎
app.engine('html', require('express-art-template'))
app.set('views', path.join(__dirname, 'client/views'));

app.get(PREV_LINK, function (req, res) {
  res.render('index.html', {
    static_link: PREV_LINK + 'client/'
  });
});

app.use('*', async (req, res) => {
  res.send({
    err_code: -port,
    msg: `not found request！in ${port}`
  })
})

app.listen(port, async () => {
  console.log(`node server runing in ${port}... `)
})