const config = {
  SUCCESS_CODE: 0,
  ERROR_CODE: -1
}

const baseConfig = {
  port: 9999
}

module.exports = {
  config,
  baseConfig
}