const mysql = require('mysql');
const db = mysql.createConnection({
  host: '127.0.0.1',
  port: 3306,
  user: 'smile',
  password: 'woaiwo1234!',
  database: 'test_tbs'
});

db.connect(function (err) {
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }
  console.log('connected as id ' + db.threadId);
});

module.exports = db;

// db.end();